from django.apps import AppConfig


class AppshowConfig(AppConfig):
    name = 'Appshow'
